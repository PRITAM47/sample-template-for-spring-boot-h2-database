package com.verizon.sydra.catalogueservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogueServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
